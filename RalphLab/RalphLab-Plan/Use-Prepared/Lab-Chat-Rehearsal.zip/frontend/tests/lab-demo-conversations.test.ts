import assert from "node:assert/strict";
import test from "node:test";
import { listConversations, messageJobId, privateThreadId } from "../src/lib/lab-demo/conversations.ts";
import { createDemoStore, createLabDemo, createMockTransport, DEMO_PLAYBOOK } from "../src/lib/lab-demo/engine.ts";
import { initialState, type DemoScope } from "../src/lib/lab-demo/events.ts";
import { demoJobTitle } from "../src/lib/lab-demo/intent.ts";

const scope: DemoScope = { userId: "guest", projectId: "p1", mode: "demo" };
const exp = "D01";

test("the inbox exposes every private agent before the user writes", () => {
  const inbox = listConversations(initialState(scope.projectId), exp);
  assert.equal(inbox.length, 5);
  assert.ok(inbox.every((c) => c.kind === "private" && !c.time && !c.preview));
});

test("two promoted tasks in one project retain separate titles, previews, members and replies", async () => {
  const store = createDemoStore();
  const engine = createLabDemo({ scope, store, experimentId: exp, transport: createMockTransport(), playbook: DEMO_PLAYBOOK });
  const first = await engine.submit("analyst", "ช่วยทำคลีนเซอร์สำหรับผิวเป็นสิวง่ายให้หน่อย");
  await engine.idle();
  const second = await engine.submit("evaluator", "ช่วยสร้างครีมสำหรับผิวแห้งให้หน่อย");
  await engine.idle();
  const inbox = () => listConversations(engine.state(), exp);
  const groups = inbox().filter((c) => c.kind === "group");
  assert.equal(groups.length, 2);
  assert.equal(groups[0].jobId, second.jobId);
  assert.equal(groups[0].title, "ครีมสำหรับผิวแห้ง");
  assert.deepEqual(groups[0].agents, ["evaluator", "director", "researcher", "formulator", "analyst"]);
  assert.equal(groups[1].title, "คลีนเซอร์สำหรับผิวเป็นสิวง่าย");
  assert.deepEqual(groups[1].agents, ["analyst", "director", "researcher", "formulator", "evaluator"]);
  assert.ok(groups.every((row) => row.time && row.preview.includes("Evaluator")));
  const before = engine.state();
  const pointedJobs = before.messages.filter((m) => m.kind === "pointer" && m.threadId === privateThreadId(scope.projectId, exp, "analyst"));
  assert.equal(pointedJobs.length, 1);
  assert.equal(messageJobId(before, pointedJobs[0]), first.jobId);
  engine.submitGroup(first.jobId!, "สรุปงานนี้ให้หน่อย");
  const after = engine.state();
  const followups = after.messages.slice(before.messages.length);
  assert.deepEqual(followups.map((m) => m.kind), ["user", "agent"]);
  assert.ok(followups.every((m) => messageJobId(after, m) === first.jobId && m.threadId === after.jobs[first.jobId!].threadId));
  assert.equal(Object.keys(after.handoffs).length, Object.keys(before.handoffs).length);
  const updated = inbox().filter((c) => c.kind === "group");
  assert.equal(updated[0].jobId, first.jobId);
  assert.match(updated[0].preview, /คลีนเซอร์/);
  assert.equal(updated[1].preview, groups[0].preview);
  engine.submitGroup("missing", "สอบถาม");
  engine.submitGroup(first.jobId!, " ");
  assert.equal(engine.state(), after);
});

test("the inbox keeps signed-in scopes separate and accepts an explicit task title", () => {
  const store = createDemoStore();
  const threadId = privateThreadId(scope.projectId, exp, "analyst");
  store.emit(scope, { type: "handoff.sent", jobId: "j", taskId: "t", handoffId: "h", from: "analyst",
    to: "director", title: "ขอเปิดโจทย์ · ช่วยทำโทนเนอร์หน่อย", jobTitle: "ทดลองโทนเนอร์ฤดูหนาว",
    sourceMessageId: "m", attempt: 1, experimentId: exp, threadId });
  assert.equal(store.get(scope).jobs.j.title, "ทดลองโทนเนอร์ฤดูหนาว");
  assert.equal(demoJobTitle("ช่วยทำโทนเนอร์ให้หน่อย"), "โทนเนอร์");
  assert.deepEqual(store.get({ ...scope, userId: "another-user" }).messages, []);
});
