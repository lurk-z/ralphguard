'use client'

import { useState, type ReactNode } from 'react'
import { ArrowRight, ChevronDown, Circle, CircleAlert, CircleCheck, Hourglass, LoaderCircle, RotateCw, Users } from 'lucide-react'
import { ROLE_EN } from '@/lib/lab-demo/engine'
import type { AgentRole, ChatMessage, Handoff, HandoffStatus, Job, StepStatus, Task } from '@/lib/lab-demo/events'
import { messageJobId } from '@/lib/lab-demo/conversations'
import { AgentFace, UserFace } from './DemoConversations'
import MessageMeta from './MessageMeta'
import type { AgentDemo } from './useAgentDemo'

const STATUS: Record<HandoffStatus, { label: string; className: string; Icon: typeof CircleCheck }> = {
  sending: { label: 'กำลังส่ง', className: 'text-sky-800 bg-sky-50 ring-sky-200', Icon: LoaderCircle },
  retrying: { label: 'ส่งไม่สำเร็จ · กำลังลองใหม่', className: 'text-amber-800 bg-amber-50 ring-amber-200', Icon: LoaderCircle },
  failed: { label: 'ส่งไม่สำเร็จ', className: 'text-rose-800 bg-rose-50 ring-rose-200', Icon: CircleAlert },
  accepted: { label: 'รับงานแล้ว', className: 'text-emerald-800 bg-emerald-50 ring-emerald-200', Icon: CircleCheck },
}

function SenderMessage({ role, first, label, children }: { role: AgentRole; first: boolean; label?: string; children: ReactNode }) {
  return <div className="flex items-start gap-2">
    {first ? <AgentFace role={role} size={28} /> : <span aria-hidden="true" className="w-7 shrink-0" />}
    <div className="min-w-0 flex-1">
      {first && <p className="mb-1 truncate text-[11px] font-normal leading-4 text-slate-500" title={ROLE_EN[role]}>
        {ROLE_EN[role]} {label && <span className="ml-1 text-[10px]">{label}</span>}
      </p>}
      {children}
    </div>
  </div>
}

function HandoffLine({ handoff, onRetry }: { handoff: Handoff; onRetry: () => void }) {
  const status = STATUS[handoff.status]
  const spinning = handoff.status === 'sending' || handoff.status === 'retrying'
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700" data-handoff-id={handoff.handoffId} data-status={handoff.status}>
      <p className="flex flex-wrap items-center gap-x-1.5 gap-y-1 font-medium text-slate-800">
        <span>{ROLE_EN[handoff.from]}</span>
        <ArrowRight aria-label="ส่งถึง" className="size-3.5 shrink-0 text-slate-500" />
        <span>{ROLE_EN[handoff.to]}</span>
        <span className="text-slate-500">· {handoff.experimentId}</span>
      </p>
      <p className="mt-0.5 break-words [overflow-wrap:anywhere]">{handoff.title}</p>
      <div className="mt-1.5 flex flex-wrap items-center gap-2">
        <span role="status" className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 ring-1 ${status.className}`}>
          <status.Icon aria-hidden="true" className={`size-3.5 ${spinning ? 'animate-spin motion-reduce:animate-none' : ''}`} />
          {handoff.status === 'sending' && handoff.attempts > 1 ? 'กำลังลองส่งอีกครั้ง' : status.label}
          {handoff.attempts > 1 && <span className="tabular-nums opacity-80">· ครั้งที่ {handoff.attempts}</span>}
        </span>
        {handoff.status === 'failed' && (
          <button type="button" onClick={onRetry} className="inline-flex min-h-8 items-center gap-1 rounded-full bg-teal-700 px-3 text-white hover:bg-teal-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-600">
            <RotateCw aria-hidden="true" className="size-3.5" /> ลองอีกครั้ง
          </button>
        )}
      </div>
    </div>
  )
}

const STEP: Record<StepStatus, { label: string; Icon: typeof Circle; className: string }> = {
  done: { label: 'เสร็จแล้ว', Icon: CircleCheck, className: 'text-emerald-700' },
  active: { label: 'กำลังทำ', Icon: LoaderCircle, className: 'text-sky-700 animate-spin motion-reduce:animate-none' },
  waiting: { label: 'รอ', Icon: Hourglass, className: 'text-amber-700' },
  pending: { label: 'ยังไม่เริ่ม', Icon: Circle, className: 'text-slate-400' },
}

/**
 * Expandable progress of one task, under its owner's acceptance message. Each message keeps
 * its own open state, so folding one agent's list never folds another's. Rows update in place.
 */
function TaskChecklist({ task }: { task: Task }) {
  const [open, setOpen] = useState(true)
  const done = task.steps.filter((step) => step.status === 'done').length
  const id = `steps-${task.taskId.replace(/[^a-zA-Z0-9-]/g, '-')}`
  return (
    <div className="mt-2 rounded-xl border border-slate-200 bg-white text-xs" data-task-id={task.taskId} data-task-status={task.status}>
      <button type="button" aria-expanded={open} aria-controls={id} onClick={() => setOpen((value) => !value)} className="flex min-h-9 w-full items-center gap-2 rounded-xl px-3 py-1.5 text-left font-medium text-slate-800 hover:bg-slate-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-teal-600">
        <span className="min-w-0 flex-1 truncate">{ROLE_EN[task.owner]} · {task.title}</span>
        <span className="shrink-0 tabular-nums text-slate-600" data-progress>{task.status === 'completed' ? 'เสร็จแล้ว' : `${done}/${task.steps.length}`}</span>
        <ChevronDown aria-hidden="true" className={`size-3.5 shrink-0 text-slate-500 transition-transform motion-reduce:transition-none ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <ol id={id} className="space-y-1 border-t border-slate-100 px-3 py-2">
          {task.steps.map((step) => {
            const look = STEP[step.status]
            return (
              <li key={step.stepId} className="flex items-start gap-2" data-step={step.stepId} data-step-status={step.status}>
                <look.Icon aria-hidden="true" className={`mt-0.5 size-3.5 shrink-0 ${look.className}`} />
                <span className="min-w-0 flex-1 break-words [overflow-wrap:anywhere]">
                  <span className="sr-only">{look.label}: </span>
                  <span className={step.status === 'pending' ? 'text-slate-500' : 'text-slate-800'}>{step.label}</span>
                  {step.note && <span className="block text-amber-800">{step.note}</span>}
                </span>
              </li>
            )
          })}
          {task.summary && <li className="border-t border-slate-100 pt-1.5 text-slate-700">{task.summary}</li>}
        </ol>
      )}
    </div>
  )
}

/**
 * One thread rendered from the shared demo state: an agent's private thread, or the project
 * group (`group`), where every message carries its experiment label.
 */
export default function AgentDemoThread({ demo, threadId, job, highlightId, onOpenGroup }: {
  demo: AgentDemo
  threadId: string
  job?: Job
  /** Message the user arrived at through a pointer: briefly outlined. */
  highlightId?: string | null
  onOpenGroup: (jobId: string, targetMessageId: string) => void
}) {
  const messages = demo.state.messages.filter((m) => m.threadId === threadId && (!job || messageJobId(demo.state, m) === job.jobId))
  const times = new Map(demo.state.log.map((event) => [event.sequence, event.occurredAt]))
  let lastSpeaker: AgentRole | 'user' | 'system' | null = null

  return messages.map((message: ChatMessage) => {
    const speaker: AgentRole | 'user' | 'system' = message.kind === 'user' ? 'user'
      : message.kind === 'handoff' ? demo.state.handoffs[message.handoffId].from
      : message.kind === 'pointer' || message.kind === 'job-intro' ? 'system'
      : message.from
    const showSpeaker = speaker !== 'user' && speaker !== 'system' && speaker !== lastSpeaker
    lastSpeaker = speaker
    const common = {
      'data-message-id': message.messageId,
      'data-kind': message.kind,
      tabIndex: -1,
      className: `mb-4 min-w-0 rounded-xl outline-none transition-shadow ${message.messageId === highlightId ? 'ring-2 ring-teal-600 ring-offset-4' : ''}`,
    }
    if (message.kind === 'user') {
      return (
        <article key={message.messageId} {...common} className={`${common.className} lab-chat-message flex max-w-[90%] items-start gap-2 self-end`}>
          <div className="min-w-0">
            <p className="whitespace-pre-wrap break-words rounded-2xl rounded-tr-md bg-teal-50 px-3 py-2 text-sm leading-relaxed [overflow-wrap:anywhere]">{message.text}</p>
            <MessageMeta text={message.text} time={times.get(message.sequence)} outgoing />
          </div>
          <UserFace viewer={demo.viewer} />
        </article>
      )
    }
    if (message.kind === 'handoff') {
      const handoff = demo.state.handoffs[message.handoffId]
      return (
        <article key={message.messageId} {...common}>
          <SenderMessage role={handoff.from} first={showSpeaker} label={job?.experimentId}>
            <HandoffLine handoff={handoff} onRetry={() => void demo.retry(handoff.handoffId)} />
          </SenderMessage>
        </article>
      )
    }
    if (message.kind === 'pointer') {
      return (
        <article key={message.messageId} {...common}>
          <button type="button" onClick={() => onOpenGroup(message.jobId, message.targetMessageId)} className="flex w-full min-h-11 items-center gap-2 rounded-xl border border-teal-200 bg-teal-50 px-3 py-2 text-left text-xs text-teal-900 hover:bg-teal-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-teal-600">
            <Users aria-hidden="true" className="size-4 shrink-0" />
            <span className="min-w-0 flex-1">
              <span className="block break-words font-semibold [overflow-wrap:anywhere]">{demo.state.jobs[message.jobId].title}</span>
              <span className="block text-teal-800">{message.experimentId} · เปิดข้อความในกลุ่ม</span>
            </span>
            <ArrowRight aria-hidden="true" className="size-4 shrink-0" />
          </button>
        </article>
      )
    }
    if (message.kind === 'job-intro') {
      return (
        <article key={message.messageId} {...common} className={`${common.className} border-y border-slate-200 py-2 text-xs text-slate-600`}>
          <p className="font-semibold text-slate-800"><span className="mr-1.5 rounded bg-slate-100 px-1.5 py-0.5 text-[11px] text-slate-600">{message.experimentId}</span>งานย้ายมาจากแชตส่วนตัวของ {ROLE_EN[demo.state.jobs[message.jobId]?.assignees[0] ?? 'analyst']}</p>
          <p className="mt-0.5">ผู้รับผิดชอบ: {message.assignees.map((role) => ROLE_EN[role]).join(', ')}</p>
        </article>
      )
    }
    const taskId = message.kind === 'acceptance' ? demo.state.handoffs[message.handoffId]?.taskId : message.taskId
    const task = taskId ? demo.state.tasks[taskId] : undefined
    return (
      <article key={message.messageId} {...common} className={`${common.className} lab-chat-message text-sm leading-7`}>
        <SenderMessage role={message.from} first={showSpeaker} label={job?.experimentId}>
          <p className="w-fit whitespace-pre-wrap break-words rounded-2xl rounded-tl-md bg-slate-100 px-3 py-2 leading-relaxed [overflow-wrap:anywhere]">{message.text}</p>
          {task && task.steps.length > 0 && <TaskChecklist task={task} />}
          <MessageMeta text={message.text} time={times.get(message.sequence)} />
        </SenderMessage>
      </article>
    )
  })
}
